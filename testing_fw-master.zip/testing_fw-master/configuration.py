MODULES_AND_SCENARIOS = {
    'ransomware': {
        'fernet': {
            'script': 'fernet.py',
            'interpreter': 'python3'
        },
    },
    'worm': {
        'scan': {
            'script': 'scan.sh',
            'interpreter': 'bash'
        }
    }
}
