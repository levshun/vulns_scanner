import os
import subprocess
from configuration import MODULES_AND_SCENARIOS


def print_all_modules():
    print('Available modules:')
    for module in MODULES_AND_SCENARIOS:
        print('-', module)
    print('\nUsage: -m <module>\n')


def print_all_scenarios(module):
    print(f'Scenarios, available for the "{module}" module:')
    for scenario in MODULES_AND_SCENARIOS[module]:
        print('-', scenario)
    print('\nUsage: -s <scenario>\n')


def run_subprocess(interpreter, script, module, arguments):
    command = [interpreter, f'modules{os.sep}{module}{os.sep}{script}']
    if arguments:
        command.append(arguments)

    print(f'\nCommand used:\n{command}\n')

    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT
    )

    output = process.communicate()
    output = list(output)[0].decode('utf-8').split('\n')
    print(f'Result:\n{output}\n')

    return process.returncode, process.pid



