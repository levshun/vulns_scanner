import os
import sys
from cryptography.fernet import Fernet

key_path = f'{__file__.split(".")[0]}_support{os.sep}encryption.key'
def_dir = f'{__file__.split(".")[0]}_support{os.sep}folder_to_encrypt{os.sep}'


def encrypt_dir(dir_path):
    try:
        with open(key_path, "rb") as filekey:
            key = filekey.read()

        fernet = Fernet(key)

        file_pathes = [f for f in os.listdir(dir_path) if os.path.isfile(os.path.join(dir_path, f))]
        print(f'Following files were found in "{dir_path}":\n{file_pathes}\n')

        for file_path in file_pathes:
            with open(f'{dir_path}{file_path}', "rb") as file:
                original = file.read()

            encrypted = fernet.encrypt(original)

            with open(f'{dir_path}{file_path}', "wb") as encrypted_file:
                encrypted_file.write(encrypted)

            print(f"File '{file_path}' was successfully encrypted by the Fernet algorithm.")

    except Exception as ex:
        print(ex)


if __name__ == '__main__':
    if len(sys.argv) > 1:
        encrypt_dir(sys.argv[1].replace('dir=', '').strip())
    else:
        print(f'Dir to encrypt is not provided, thus default is used.\n')
        encrypt_dir(def_dir)

