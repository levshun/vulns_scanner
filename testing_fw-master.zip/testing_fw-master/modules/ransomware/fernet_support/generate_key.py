from cryptography.fernet import Fernet

key = Fernet.generate_key()

with open(f'encryption.key', 'wb') as filekey:
   filekey.write(key)
