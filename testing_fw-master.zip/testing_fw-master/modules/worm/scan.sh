#!/bin/bash

is_alive_ping()
{
  ping -c 1 $1 > /dev/null
  if [ $? -eq 0 ]; then
    echo "$1 is up"
  fi
}

if [ -z "$1" ]
then
  echo "Error: IP address was not provided."
else
  if [[ $1 =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    nw="$(cut -d. -f1-3 <<<$1)"

    for i in $nw.{2..254}
    do
      if [ $i != $1 ]; then
        is_alive_ping $i & disown
        sleep 0.001
      fi
    done
  else
    echo "Error: provided IP is not valid."
  fi
fi
