import sys
import getopt

from support_functions import \
    print_all_modules, print_all_scenarios, \
    run_subprocess

from configuration import MODULES_AND_SCENARIOS


def get_args(argv):
    arg_module = None
    arg_scenario = None
    arg_arguments = None
    arg_help = \
        "You can execute Tester like this:\n" + \
        "python {0} --module <module> --scenario <scenario> --arguments <arguments>".format(argv[0]) + \
        "\n\nOr like this:\n" + \
        "python {0} -m <module> -s <scenario> -a <arguments>".format(argv[0]) + \
        "\n\nList of available modules can be found like this:\n" \
        "python {0} -m help".format(argv[0]) + \
        "\n\nList of available scenarios can be found like this:\n" \
        "python {0} -m <module> -s help ".format(argv[0])

    try:
        opts, args = getopt.getopt(
            argv[1:], "hm:s:a:",
            ["help", "module=", "scenario=", "arguments="]
        )

    except:
        print(arg_help)
        sys.exit(2)

    for opt, arg in opts:
        if opt in ("-h", "--help"):
            print(arg_help)
            sys.exit(2)

        elif opt in ("-m", "--module"):
            arg_module = arg

        elif opt in ("-s", "--scenario"):
            arg_scenario = arg

        elif opt in ("-a", "--arguments"):
            arg_arguments = arg

    return arg_help, arg_module, arg_scenario, arg_arguments


def parse_args(module, scenario, arguments):
    if all(arg is None for arg in (module, scenario, arguments)):
        print(f_help)
        sys.exit(2)

    else:
        if module == 'help':
            print_all_modules()
            sys.exit(2)

        elif module in MODULES_AND_SCENARIOS:
            if scenario == 'help':
                print_all_scenarios(module)
                sys.exit(2)

            elif scenario in MODULES_AND_SCENARIOS[module]:
                interpreter = MODULES_AND_SCENARIOS[module][scenario]['interpreter']
                script = MODULES_AND_SCENARIOS[module][scenario]['script']
                run_subprocess(interpreter, script, module, arguments)

            else:
                print(f'Error: the "{scenario}" scenario is not present in configuration.py\n')
                print_all_scenarios(module)
                sys.exit(2)

        else:
            print(f'Error: the "{module}" module is not present in configuration.py\n')
            print_all_modules()
            sys.exit(2)


if __name__ == '__main__':
    f_help, f_module, f_scenario, f_arguments = get_args(sys.argv)
    parse_args(f_module, f_scenario, f_arguments)
